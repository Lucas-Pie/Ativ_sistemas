const express = require('express');
const app = express();
const path = require('path');

const database = require('./database');
const Aluno = require('./models/Aluno');


app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const PORT = 3000;



app.get('/', async (req, res) => {
    try {
        const alunos = await Aluno.findAll();

        res.render('index', {
            alunos: alunos
        });

    } catch (error) {
        res.status(500).send(
            'Erro ao buscar alunos: ' + error.message
        );
    }
});



app.get('/novo', (req, res) => {
    res.render('novo');
});

app.post('/cadastrar', async (req, res) => {
    try {
        const { nome, RA, email, senha } = req.body;

        await Aluno.create({
            nome,
            RA,
            email,
            senha
        });

        res.redirect('/');

    } catch (error) {
        res.status(500).send(
            'Erro ao cadastrar aluno: ' + error.message
        );
    }
});



app.get('/editar/:id', async (req, res) => {
    try {
        const aluno = await Aluno.findByPk(req.params.id);

        if (aluno) {
            res.render('editar', {
                aluno: aluno
            });
        } else {
            res.status(404).send('Aluno não encontrado.');
        }

    } catch (error) {
        res.status(500).send(
            'Erro ao carregar aluno: ' + error.message
        );
    }
});



app.post('/editar/:id', async (req, res) => {
    try {
        const { nome, RA, email, senha } = req.body;

        await Aluno.update(
            {
                nome,
                RA,
                email,
                senha
            },
            {
                where: {
                    id_aluno: req.params.id
                }
            }
        );

        res.redirect('/');

    } catch (error) {
        res.status(500).send(
            'Erro ao atualizar aluno: ' + error.message
        );
    }
});



app.get('/excluir/:id', async (req, res) => {
    try {
        await Aluno.destroy({
            where: {
                id_aluno: req.params.id
            }
        });

        res.redirect('/');

    } catch (error) {
        res.status(500).send(
            'Erro ao excluir aluno: ' + error.message
        );
    }
});



async function iniciarServidor() {
    try {

        await database.authenticate();

        console.log('Conexão MYSQL = Okay');

        
        await database.sync();

        console.log('Conexão do Banco de Dados = Okay');

        app.listen(PORT, () => {
            console.log(
                `Servidor rodando em http://localhost:${PORT}`
            );
        });

    } catch (error) {

        console.error(
            'Erro ao conectar ao MySQL:',
            error.message
        );

    }
}

iniciarServidor();
