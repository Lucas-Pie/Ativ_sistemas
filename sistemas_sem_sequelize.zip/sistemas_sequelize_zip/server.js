const express = require('express');
const app = express();
const path = require('path');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

let alunos = [];
let proximoId = 1;

app.get('/', (req, res) => {
    res.render('index', { alunos: alunos });
});

app.get('/novo', (req, res) => {
    res.render('novo');
});

app.post('/cadastrar', (req, res) => {
    const { nome, RA, email, senha } = req.body;
    
    const novoAluno = {
        id_aluno: proximoId++,
        nome,
        RA,
        email,
        senha
    };
    
    alunos.push(novoAluno);
    res.redirect('/');
});

app.get('/editar/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const aluno = alunos.find(a => a.id_aluno === id);
    
    if (aluno) {
        res.render('editar', { aluno: aluno });
    } else {
        res.status(404).send('Aluno não encontrado.');
    }
});

app.post('/editar/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const { nome, RA, email, senha } = req.body;
    
    const indice = alunos.findIndex(a => a.id_aluno === id);
    
    if (indice !== -1) {
        alunos[indice] = { id_aluno: id, nome, RA, email, senha };
        res.redirect('/');
    } else {
        res.status(404).send('Aluno não encontrado.');
    }
});

app.get('/excluir/:id', (req, res) => {
    const id = parseInt(req.params.id);
    alunos = alunos.filter(a => a.id_aluno !== id);
    res.redirect('/');
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
